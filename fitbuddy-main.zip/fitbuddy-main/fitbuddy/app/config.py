from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):

    app_name: str = "FitBuddy – AI Fitness Plan Generator"

    environment: str = "development"

    database_url: str = "sqlite:///./fitbuddy.db"

    gemini_api_key: str = ""

    gemini_workout_model: str = "gemini-3.8-flash"

    gemini_tip_model: str = "gemini-3.5-flash-lite"

    use_mock_ai: bool = False

    admin_username: str = "admin"

    admin_password: str = "change-me"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()